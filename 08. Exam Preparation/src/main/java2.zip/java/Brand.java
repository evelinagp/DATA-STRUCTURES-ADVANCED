public enum Brand
{
    HP,
    DELL,
    ASUS,
    ACER
}
