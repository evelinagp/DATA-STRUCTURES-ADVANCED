public enum Department {
    SELLS,
    INCOMES,
    INTERNALS,
    WASTAGE,
    OTHERS;
}
